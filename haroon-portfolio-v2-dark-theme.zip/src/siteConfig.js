// Quick switches for the site's effects. Change a value and save.
export const SITE = {
  cursor: "ring", // "ring" (ring + dot) | "glow" (soft spotlight) | "dot" (glowing dot) | "off"
  background: "particles", // "particles" | "off"
  // Caption shown on the hero image. Edit it to say what the achievement was.
  achievement: { label: "Teacher Award", caption: "With Qasim Ali Shah" },
};
