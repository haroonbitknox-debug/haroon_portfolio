import { useEffect, useRef } from "react";
import { SITE } from "../siteConfig";

const INTERACTIVE = "a, button, [role='button'], select, summary, .hub-card, .contact-item";
const TEXT_FIELD = "input, textarea, [contenteditable='true']";

/** Pretty cursor. Variants: "ring" | "glow" | "dot" | "off" (see siteConfig.js). Mouse devices only. */
export default function CustomCursor({ variant = SITE.cursor }) {
  const dot = useRef(null);
  const ring = useRef(null);

  useEffect(() => {
    if (variant === "off") return;
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return; // skip touch screens
    const calm = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const root = document.documentElement;
    const mode = `cursor-v-${variant}`;
    root.classList.add("cursor-on", mode);

    let x = -100, y = -100, rx = -100, ry = -100, raf;
    const onMove = (e) => {
      x = e.clientX;
      y = e.clientY;
      root.classList.add("cursor-seen");
      if (dot.current) dot.current.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    };
    const onOver = (e) => {
      const el = e.target;
      root.classList.toggle("cursor-link", !!el.closest?.(INTERACTIVE));
      root.classList.toggle("cursor-text", !!el.closest?.(TEXT_FIELD));
    };
    const onDown = () => root.classList.add("cursor-down");
    const onUp = () => root.classList.remove("cursor-down");
    const onLeave = () => root.classList.remove("cursor-seen");

    const tick = () => {
      const k = calm ? 1 : 0.18; // how closely the ring follows the pointer
      rx += (x - rx) * k;
      ry += (y - ry) * k;
      if (ring.current) ring.current.style.transform = `translate3d(${rx}px, ${ry}px, 0)`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerover", onOver, { passive: true });
    window.addEventListener("pointerdown", onDown);
    window.addEventListener("pointerup", onUp);
    document.addEventListener("pointerleave", onLeave);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerover", onOver);
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      document.removeEventListener("pointerleave", onLeave);
      root.classList.remove("cursor-on", mode, "cursor-seen", "cursor-link", "cursor-text", "cursor-down");
    };
  }, [variant]);

  if (variant === "off") return null;
  return (
    <>
      <div ref={ring} className="cursor-ring" aria-hidden="true">
        <span />
      </div>
      <div ref={dot} className="cursor-dot" aria-hidden="true" />
    </>
  );
}
