// Quick switch for the site's effects. Change the value and save.
export const SITE = {
  background: "particles", // "particles" | "off"
};
